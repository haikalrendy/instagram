<?php
session_start(); // Memulai sesi

// Hapus semua data sesi
session_unset();

// Hapus sesi dari server
session_destroy();

// Redirect ke halaman login atau halaman lain yang diinginkan
header("Location: login.php");
exit();
?>
<?php
session_start();
if(!isset($_SESSION['login'])){
    header ("location:index.php?login=sukses");
}
include 'koneksi.php';
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Casualgram</title>
  <link rel="icon" href="logo.png">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <title></title>

    <style>
      body {
        background-image: url(/insta/images/logo3.png);
      }
    .zoom {
      transition: transform .2s;
      /* Animation */
      margin: 0 auto;
    }

    .zoom:hover {
      transform: scale(1.1);
      /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
    }
</style>

</head>
<nav class="navbar navbar-expand-lg bg-body-tertiary sticky-top">
  <div class="container-fluid">
  <a class="navbar-brand" href="#">
    <img src="logo.png" width="80" height="80" alt=""> 
    Casualgram
  </a>
  <button type="button" class="btn btn-primary bi bi-plus-square" data-bs-toggle="modal" data-bs-target="#exampleModal"></button>
  </div>
    <div>
      <form class="d-flex" role="search">
      
        <a href="logout.php"><button class="btn btn-sm btn-secondary" type="button"><i class="bi bi-box-arrow-right"></i></button></a>
      </form>
  </div>
</nav><br><br>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Post Modal</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">Foto</label>
        <input type="file" name="foto" class="form-control" required><br>

        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control"autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input type="text" name="lokasi" class="form-control"autocomplete="off"><br>
      </div>
      <div class="modal-footer">
      <input class="btn btn-success" type="submit" value="Post" name="simpan">
        </div>
      </form>
    </div>
  </div>
</div>

    <?php while ($post = mysqli_fetch_assoc($query)) { ?>


   <div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4">
<div class="zoom">
<div class="card mt-5 shadow-lg p-3 mb-5 bg-white rounded" style="width: 25rem;">
  <img class="card-img-top" src="images/<?=$post['foto']?>" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title"><?=$post['lokasi']?></h5>
    <p class="card-text"><?=$post['caption']?></p>
    <a href="edit.php?no=<?=$post['no']?>" class="btn btn-warning" data-bs-toggle="modal"
            data-bs-target="#editModal<?= $post['no'] ?>"><i class="bi bi-pencil"></i></a>
    <a href="hapus.php?no=<?=$post['no']?>" class="btn btn-primary"><i class="bi bi-trash"></i></a>

  </div>
  </div>
</div>
</div>
</div>
</div>
<br><br>

<div class="modal fade" id="editModal<?= $post['no'] ?>" data-bs-backdrop="static" data-bs-keyboard="false"
          tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Form Edit Postingan</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="container" align="left">
                <form action="proses_edit.php" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="no" value="<?= $post['no'] ?>">
                  <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>" class="form-control">

                  <label for="">foto</label>
                  <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" class="form-control"><br>
                  <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>
                  <label for="">Caption</label>
                  <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control"><br>
                  <label for="">Lokasi</label>
                  <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control"><br>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="update">Update</button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LoginCasualgram</title>
    <link rel="icon" href="logo.png">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="loginBox"> <img class="user" src="logo.png" height="130px" width="130px">
        <h3>Login</h3>
        <form action="proses_login.php" method="post">
            <div class="inputBox"> 
                <input type="text" name="username" placeholder="Username"> 
                <input type="password" name="password" placeholder="Password"> 
            </div> 
            <input type="submit" name="" value="Login">
        </form> 

    </div>
</body>
</html>